# DesignPatternsJava9
This repository consists Gang of Four Design patterns code example used for course https://www.packtpub.com/application-development/learn-design-patterns-java-9-video

Each branch in the repository has working example code for 1 design pattern. 

To look at code of Decorator pattern you might have to switch to branch decorator pattern eg. link   https://github.com/premaseem/DesignPatternsJava9/tree/decorator-pattern

Note: This code base will work on Java 9 and above  versions. 
